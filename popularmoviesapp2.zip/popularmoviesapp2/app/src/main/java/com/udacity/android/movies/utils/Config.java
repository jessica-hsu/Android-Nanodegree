package com.udacity.android.movies.utils;

/**
 * hold global variables here like API_KEY
 */
public class Config {

    protected final static String API_KEY = "";
}
